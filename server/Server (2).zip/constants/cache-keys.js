module.exports = {
    EXPENSES: "expenses",
    EXPENSESBYMONTH: "expensesByMonth",
    BUDGETS: "budgets",
    BUDGETSBYMONTH: "budgetsByMonth"
}