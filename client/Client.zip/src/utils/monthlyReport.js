import { fetchExpenseByMonth } from "../api";
// import { category } from "../constants/constant";

export const getMonthlyCategorySpent = async (month) => {
  // const monthlyExpense = await fetchExpenseByMonth(month);
  // let food = 0,
  //   travel = 0,
  //   clothing = 0,
  //   other = 0;
  // monthlyExpense.data.forEach(({ transaction }) => {
  //   if (transaction.category === category.food) food += transaction.amount;
  //   if (transaction.category === category.clothing)
  //     clothing += transaction.amount;
  //   if (transaction.category === category.travel) travel += transaction.amount;
  //   if (transaction.category === category.other) other += transaction.amount;
  //   console.log(transaction);
  // });

  // console.log("monthlyExp", monthlyExpense);
  // console.log("report", { food, travel, clothing, other });
  // return [food, travel, clothing, other];
};



