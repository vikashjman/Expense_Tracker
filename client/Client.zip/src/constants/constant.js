export const CATEGORY = {
  food: "FOOD",
  travel: "TRAVEL",
  education: "EDUCATION",
  medical: "MEDICAL",
  other: "OTHER",
  groceries: "GROCERIES",
  entertainment: "ENTERTAINMENT",
};

export const MONTH = {
  january: "JANUARY",
  february: "FEBRUARY",
  march: "MARCH",
  april: "APRIL",
  may: "MAY",
  june: "JUNE",
  july: "JULY",
  august: "AUGUST",
  september: "SEPTEMBER",
  october: "OCTOBER",
  november: "NOVEMBER",
  december: "DECEMBER",
};
