import React from "react";
import Container from "react-bootstrap/Container";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import { Nav } from "react-bootstrap"; // Import Nav component

function TopNav() {
  return (
    <Navbar className="bg-body-tertiary" expand="lg"> {/* Add expand="lg" to enable the responsive behavior */}
      <Container>
        <Navbar.Brand href="#home">Expense Tracker</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" /> {/* Add aria-controls to link the toggle to the navbar content */}
        <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end"> {/* Add id and justify-content-end */}
          <Navbar.Text className="mr-3"> {/* Add margin-right for spacing */}
            Signed in as:
          </Navbar.Text>
          <NavDropdown title="Link" id="navbarScrollingDropdown" alignRight> {/* Add alignRight to dropdown */}
            <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
            <NavDropdown.Item href="#action4">
              Another action
            </NavDropdown.Item>
            <NavDropdown.Divider />
            <NavDropdown.Item href="#action5">
              Something else here
            </NavDropdown.Item>
          </NavDropdown>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default TopNav;
